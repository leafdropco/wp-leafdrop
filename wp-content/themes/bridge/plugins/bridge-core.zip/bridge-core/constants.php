<?php

define( 'BRIDGE_CORE_VERSION', '2.5.4' );
define( 'BRIDGE_CORE_ABS_PATH', dirname( __FILE__ ) );
define( 'BRIDGE_CORE_REL_PATH', dirname( plugin_basename( __FILE__ ) ) );
define( 'BRIDGE_CORE_URL_PATH', plugin_dir_url( __FILE__ ) );
define( 'BRIDGE_CORE_MODULES_PATH', BRIDGE_CORE_ABS_PATH . '/modules' );
define( 'BRIDGE_CORE_MODULES_URL_PATH', BRIDGE_CORE_URL_PATH . 'modules' );
define( 'BRIDGE_CORE_SHORTCODES_PATH', BRIDGE_CORE_ABS_PATH . '/modules/shortcodes/shortcode-elements' );
define( 'BRIDGE_CORE_SHORTCODES_URL_PATH', BRIDGE_CORE_URL_PATH . 'modules/shortcodes/shortcode-elements' );
define( 'BRIDGE_CORE_OPTIONS_NAME', 'qode_options_proya' );